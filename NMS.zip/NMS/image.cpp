#include "image.h"

#include <algorithm>
#include <fstream>

Image::Image(int width, int height, Color bg)
    : w_(width), h_(height), data_(static_cast<size_t>(width) * height * 3) {
    for (int y = 0; y < h_; ++y)
        for (int x = 0; x < w_; ++x) setPixel(x, y, bg);
}

void Image::setPixel(int x, int y, Color c) {
    if (x < 0 || y < 0 || x >= w_ || y >= h_) return;
    const size_t i = (static_cast<size_t>(y) * w_ + x) * 3;
    data_[i] = c.r;
    data_[i + 1] = c.g;
    data_[i + 2] = c.b;
}

void Image::fillRect(int x1, int y1, int x2, int y2, Color c) {
    for (int y = y1; y <= y2; ++y)
        for (int x = x1; x <= x2; ++x) setPixel(x, y, c);
}

void Image::fillEllipse(int x1, int y1, int x2, int y2, Color c) {
    const double cx = (x1 + x2) / 2.0, cy = (y1 + y2) / 2.0;
    const double rx = (x2 - x1) / 2.0, ry = (y2 - y1) / 2.0;
    for (int y = y1; y <= y2; ++y)
        for (int x = x1; x <= x2; ++x) {
            const double dx = (x - cx) / rx, dy = (y - cy) / ry;
            if (dx * dx + dy * dy <= 1.0) setPixel(x, y, c);
        }
}

void Image::drawRect(int x1, int y1, int x2, int y2, Color c, int t) {
    for (int k = 0; k < t; ++k) {
        for (int x = x1 + k; x <= x2 - k; ++x) {
            setPixel(x, y1 + k, c);
            setPixel(x, y2 - k, c);
        }
        for (int y = y1 + k; y <= y2 - k; ++y) {
            setPixel(x1 + k, y, c);
            setPixel(x2 - k, y, c);
        }
    }
}

void Image::drawVerticalGradient(Color top, Color bottom) {
    for (int y = 0; y < h_; ++y) {
        const double t = h_ > 1 ? static_cast<double>(y) / (h_ - 1) : 0.0;
        Color c{static_cast<uint8_t>(top.r + (bottom.r - top.r) * t),
                static_cast<uint8_t>(top.g + (bottom.g - top.g) * t),
                static_cast<uint8_t>(top.b + (bottom.b - top.b) * t)};
        for (int x = 0; x < w_; ++x) setPixel(x, y, c);
    }
}

bool Image::savePPM(const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out << "P6\n" << w_ << " " << h_ << "\n255\n";
    out.write(reinterpret_cast<const char*>(data_.data()),
              static_cast<std::streamsize>(data_.size()));
    return static_cast<bool>(out);
}
