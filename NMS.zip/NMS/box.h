#pragma once
#include <algorithm>

// A single detection: axis-aligned box (x1,y1)-(x2,y2), confidence, class id.
struct Detection {
    float x1, y1, x2, y2;
    float score;
    int classId;

    float area() const {
        return std::max(0.0f, x2 - x1) * std::max(0.0f, y2 - y1);
    }
};

// Intersection over Union of two boxes (class is ignored here).
inline float iou(const Detection& a, const Detection& b) {
    const float ix1 = std::max(a.x1, b.x1);
    const float iy1 = std::max(a.y1, b.y1);
    const float ix2 = std::min(a.x2, b.x2);
    const float iy2 = std::min(a.y2, b.y2);
    const float inter = std::max(0.0f, ix2 - ix1) * std::max(0.0f, iy2 - iy1);
    const float uni = a.area() + b.area() - inter;
    return uni > 0.0f ? inter / uni : 0.0f;
}
