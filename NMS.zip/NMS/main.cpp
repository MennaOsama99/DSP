// NMS demo: builds a synthetic scene, fabricates noisy detector output around
// each object, runs NMS, and writes before/after images (PPM).
//
// Usage: ./nms_demo [--iou 0.5] [--score 0.3] [--soft]

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

#include "box.h"
#include "image.h"
#include "nms.h"

namespace {

const int kW = 640, kH = 480;

Color classColor(int classId) {
    static const Color palette[] = {{230, 40, 40}, {40, 200, 60}, {250, 220, 30}};
    return palette[classId % 3];
}

struct GroundTruth {
    int x1, y1, x2, y2;
    int classId;
    bool ellipse;
};

// Fake detector: many jittered, overlapping boxes per object, with scores that
// fall off as the jitter grows. Plus a few low-confidence false positives.
std::vector<Detection> fakeDetector(const std::vector<GroundTruth>& gts,
                                    std::mt19937& rng) {
    std::normal_distribution<float> jitter(0.0f, 8.0f);
    std::uniform_real_distribution<float> noise(-0.05f, 0.05f);
    std::vector<Detection> dets;

    for (const auto& g : gts) {
        for (int i = 0; i < 12; ++i) {
            float dx1 = jitter(rng), dy1 = jitter(rng);
            float dx2 = jitter(rng), dy2 = jitter(rng);
            float err = std::sqrt(dx1 * dx1 + dy1 * dy1 + dx2 * dx2 + dy2 * dy2);
            float score = std::clamp(0.97f - err / 60.0f + noise(rng), 0.05f, 0.99f);
            dets.push_back({g.x1 + dx1, g.y1 + dy1, g.x2 + dx2, g.y2 + dy2,
                            score, g.classId});
        }
    }

    // Low-confidence background false positives.
    std::uniform_real_distribution<float> px(0, kW - 100), py(0, kH - 100);
    std::uniform_real_distribution<float> sz(40, 90), sc(0.05f, 0.25f);
    for (int i = 0; i < 6; ++i) {
        float x = px(rng), y = py(rng), s = sz(rng);
        dets.push_back({x, y, x + s, y + s, sc(rng), i % 3});
    }
    return dets;
}

void drawDetections(Image& img, const std::vector<Detection>& dets, int thickness) {
    for (const auto& d : dets)
        img.drawRect(static_cast<int>(d.x1), static_cast<int>(d.y1),
                     static_cast<int>(d.x2), static_cast<int>(d.y2),
                     classColor(d.classId), thickness);
}

void printDetections(const char* title, const std::vector<Detection>& dets) {
    std::printf("%s (%zu)\n", title, dets.size());
    for (const auto& d : dets)
        std::printf("  class %d  score %.3f  box [%6.1f %6.1f %6.1f %6.1f]\n",
                    d.classId, d.score, d.x1, d.y1, d.x2, d.y2);
}

}  // namespace

int main(int argc, char** argv) {
    float iouThresh = 0.5f, scoreThresh = 0.3f;
    bool useSoft = false;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--iou") && i + 1 < argc) iouThresh = std::atof(argv[++i]);
        else if (!std::strcmp(argv[i], "--score") && i + 1 < argc) scoreThresh = std::atof(argv[++i]);
        else if (!std::strcmp(argv[i], "--soft")) useSoft = true;
        else {
            std::fprintf(stderr, "Usage: %s [--iou T] [--score T] [--soft]\n", argv[0]);
            return 1;
        }
    }

    // --- 1. Build the example image -------------------------------------
    std::vector<GroundTruth> scene = {
        {80, 120, 260, 360, 0, true},    // class 0, ellipse
        {330, 100, 470, 300, 1, false},  // class 1, rectangle
        {400, 250, 590, 430, 0, true},   // class 0, overlaps the rectangle
    };

    Image base(kW, kH);
    base.drawVerticalGradient({30, 30, 50}, {90, 90, 110});
    for (const auto& g : scene) {
        Color c = classColor(g.classId);
        c = {static_cast<uint8_t>(c.r * 0.6), static_cast<uint8_t>(c.g * 0.6),
             static_cast<uint8_t>(c.b * 0.6)};  // darken so boxes stand out
        if (g.ellipse) base.fillEllipse(g.x1, g.y1, g.x2, g.y2, c);
        else base.fillRect(g.x1, g.y1, g.x2, g.y2, c);
    }

    // --- 2. Fake raw detections ------------------------------------------
    std::mt19937 rng(42);
    std::vector<Detection> raw = fakeDetector(scene, rng);

    // --- 3. Post-process --------------------------------------------------
    std::vector<Detection> confident = filterByScore(raw, scoreThresh);
    std::vector<Detection> result = useSoft
        ? softNms(confident, /*sigma=*/0.5f, /*scoreThresh=*/scoreThresh)
        : batchedNms(confident, iouThresh);

    std::printf("Raw: %zu  after score filter (>= %.2f): %zu  after %s: %zu\n\n",
                raw.size(), scoreThresh, confident.size(),
                useSoft ? "Soft-NMS" : "NMS", result.size());
    printDetections("Final detections", result);

    // --- 4. Visualize -----------------------------------------------------
    Image before = base, after = base;
    drawDetections(before, raw, 1);
    drawDetections(after, result, 3);

    if (!before.savePPM("before_nms.ppm") || !after.savePPM("after_nms.ppm")) {
        std::fprintf(stderr, "Failed to write output images\n");
        return 1;
    }
    std::printf("\nWrote before_nms.ppm and after_nms.ppm\n");
    return 0;
}
