#include "nms.h"

#include <algorithm>
#include <cmath>
#include <map>

std::vector<Detection> filterByScore(const std::vector<Detection>& dets,
                                     float scoreThresh) {
    std::vector<Detection> out;
    for (const auto& d : dets)
        if (d.score >= scoreThresh) out.push_back(d);
    return out;
}

std::vector<Detection> nms(std::vector<Detection> dets, float iouThresh) {
    // Highest confidence first.
    std::sort(dets.begin(), dets.end(),
              [](const Detection& a, const Detection& b) { return a.score > b.score; });

    std::vector<bool> suppressed(dets.size(), false);
    std::vector<Detection> keep;

    for (size_t i = 0; i < dets.size(); ++i) {
        if (suppressed[i]) continue;
        keep.push_back(dets[i]);
        for (size_t j = i + 1; j < dets.size(); ++j) {
            if (!suppressed[j] && iou(dets[i], dets[j]) > iouThresh)
                suppressed[j] = true;
        }
    }
    return keep;
}

std::vector<Detection> batchedNms(const std::vector<Detection>& dets,
                                  float iouThresh) {
    std::map<int, std::vector<Detection>> byClass;
    for (const auto& d : dets) byClass[d.classId].push_back(d);

    std::vector<Detection> out;
    for (auto& kv : byClass) {
        auto kept = nms(kv.second, iouThresh);
        out.insert(out.end(), kept.begin(), kept.end());
    }
    std::sort(out.begin(), out.end(),
              [](const Detection& a, const Detection& b) { return a.score > b.score; });
    return out;
}

std::vector<Detection> softNms(const std::vector<Detection>& dets,
                               float sigma, float scoreThresh) {
    std::map<int, std::vector<Detection>> byClass;
    for (const auto& d : dets) byClass[d.classId].push_back(d);

    std::vector<Detection> out;
    for (auto& kv : byClass) {
        std::vector<Detection> remaining = kv.second;
        while (!remaining.empty()) {
            // Pick the current best box.
            auto bestIt = std::max_element(
                remaining.begin(), remaining.end(),
                [](const Detection& a, const Detection& b) { return a.score < b.score; });
            Detection best = *bestIt;
            remaining.erase(bestIt);
            out.push_back(best);

            // Decay the rest according to overlap with the picked box.
            for (auto& d : remaining) {
                const float o = iou(best, d);
                d.score *= std::exp(-(o * o) / sigma);
            }
            remaining.erase(
                std::remove_if(remaining.begin(), remaining.end(),
                               [&](const Detection& d) { return d.score < scoreThresh; }),
                remaining.end());
        }
    }
    std::sort(out.begin(), out.end(),
              [](const Detection& a, const Detection& b) { return a.score > b.score; });
    return out;
}
