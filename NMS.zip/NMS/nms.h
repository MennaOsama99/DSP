#pragma once
#include <vector>
#include "box.h"

// Drop detections whose score is below `scoreThresh`.
std::vector<Detection> filterByScore(const std::vector<Detection>& dets,
                                     float scoreThresh);

// Classic greedy hard-NMS (class-agnostic).
// Keeps the highest-scoring box, removes boxes with IoU > iouThresh, repeats.
std::vector<Detection> nms(std::vector<Detection> dets, float iouThresh);

// Hard-NMS run independently per class, so different classes never suppress
// each other. Result is sorted by score (descending).
std::vector<Detection> batchedNms(const std::vector<Detection>& dets,
                                  float iouThresh);

// Gaussian Soft-NMS: instead of deleting overlapping boxes, decay their score
// by exp(-IoU^2 / sigma). Boxes falling under `scoreThresh` are dropped.
// Run per class.
std::vector<Detection> softNms(const std::vector<Detection>& dets,
                               float sigma, float scoreThresh);
