#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Color {
    uint8_t r, g, b;
};

// Minimal RGB image with a few drawing helpers and PPM output.
class Image {
public:
    Image(int width, int height, Color background = {0, 0, 0});

    int width() const { return w_; }
    int height() const { return h_; }

    void setPixel(int x, int y, Color c);
    void fillRect(int x1, int y1, int x2, int y2, Color c);
    void fillEllipse(int x1, int y1, int x2, int y2, Color c);
    void drawRect(int x1, int y1, int x2, int y2, Color c, int thickness = 1);
    void drawVerticalGradient(Color top, Color bottom);

    // Writes a binary PPM (P6). Returns false on I/O error.
    bool savePPM(const std::string& path) const;

private:
    int w_, h_;
    std::vector<uint8_t> data_;  // RGB, row-major
};
